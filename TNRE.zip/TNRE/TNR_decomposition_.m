function [g1,rank_N_1]=TNR_decomposition_(X1_,d1,d2,delta_tr)
L1=ndims(X1_);
I=size(X1_);
g1=cell(1,L1);
temp=tenmat(X1_,[1],[2:L1]);
[U,lambda,V]=svds(temp.data,size(X1_,1),'largest');
rank_N_1(1)=d1;
temp=tril(ones(size(X1_,1)))*diag(lambda);
d_temp=size(find(temp<delta_tr*temp(end)),1);
% d_temp=size(find(lambda>delta_tr*lambda(1)),1);
rank_N_1(2)=max([floor(d_temp/d1),1]);
temp2=U(:,1:rank_N_1(1)*rank_N_1(2));
g1_temp=tensor(temp2(:),[size(X1_,1),rank_N_1(1),rank_N_1(2)]);
g1_t=permute(g1_temp,[2,1,3]);
g1{1}=g1_t;
temp=lambda(1:rank_N_1(1)*rank_N_1(2),:)*V';
G=tensor(temp(:),[rank_N_1(1),rank_N_1(2),I(2:end)]);
G=permute(G,[2:L1+1,1]);
for i=2:L1-1
    G_dim=ndims(G);
    temp=tenmat(G,[1,2],[3:G_dim]);
    [U,lambda,V]=svds(temp.data,size(temp,1),'largest');
%     temp=tril(ones(size(diag(lambda),1)))*diag(lambda);
%     d_temp=size(find(temp<delta_tr*temp(end)),1);
    d_temp=size(find(lambda>delta_tr*lambda(1)),1);
    if i<L1-1
    rank_N_1(i+1)=max([floor(d_temp),1]);
    else
    rank_N_1(i+1)=d2;
    end
    temp2=U(:,1:rank_N_1(i+1));
    g1_temp=tensor(temp2(:),[rank_N_1(i),size(X1_,i),rank_N_1(i+1)]);
    g1{i}=g1_temp;
    temp=lambda(1:rank_N_1(i+1),:)*V';
    G=tensor(temp(:),[rank_N_1(i+1),I(i+1:end),rank_N_1(1)]);
end
% G_dim=ndims(G);
% temp=tenmat(G,[1,2],[3:G_dim]);
% [U,lambda,V]=svd(temp.data);
% g1_temp=tensor(U(:,1:rank_N_1(1)),[rank_N_1(L1),size(X1_,L1),rank_N_1(1)]);
% g1{L1}=g1_temp;
g1{L1}=G;
end