function [X,fval]=orth_Constrain_solving2(H,L,X0,d1,d2,d3)
% tau=0.5;
%orthogonal function optimization
%edited by Tong Gao 1/7 2024
X=X0;
belta=0.2;
f=@(x)x'*H*x+L'*x;
count=0;
while true
tau=1;
G=zeros(size(X));
temp_X_t=tensor(X(:),[d1,d2,d3]);
temp_X_t2=permute(temp_X_t,[1,3,2]);
X_V=temp_X_t2.data(:);
% f(X_V)
temp_G=2*X_V'*H+L';
temp_G_t=tensor(temp_G,[d1,d3,d2]);
temp_G_t2=permute(temp_G_t,[1,3,2]);
G_V=temp_G_t2.data(:);
G(:)=G_V;
A=G*X'-X*G';
Q=((eye(size(A))+0.00001/2*A)^-1)*((eye(size(A))-0.00001/2*A));
Y=Q*X;
temp_Y_t=tensor(Y(:),[d1,d2,d3]);
temp_Y_t2=permute(temp_Y_t,[1,3,2]);
Y_V=temp_Y_t2.data(:);
Y_D=(f(Y_V)-f(X_V))/0.00001;
Q=((eye(size(A))+tau/2*A)^-1)*((eye(size(A))-tau/2*A));
Y=Q*X;
mark=0;

for i=1:100
    temp_Y_t=tensor(Y(:),[d1,d2,d3]);
    temp_Y_t2=permute(temp_Y_t,[1,3,2]);
    Y_V=temp_Y_t2.data(:);
if f(Y_V)<f(X_V)-abs(0.5*Y_D*tau)
    X=Y;
    mark=1;
    break; 
end
tau=belta*tau;
Q=((eye(size(A))+tau/2*A)^-1)*((eye(size(A))-tau/2*A));
Y=Q*X;
end
% f(Y_V)
% f(Y(:))
if mark==0||count>100
    break;
end
count=count+1;
end
temp_X_t=tensor(X(:),[d1,d2,d3]);
temp_X_t2=permute(temp_X_t,[1,3,2]);
X_V=temp_X_t2.data(:);
fval=f(X_V);
end