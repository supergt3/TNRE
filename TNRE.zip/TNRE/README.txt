TNRE.m: the implementation of the TNRE method
test.m: demo of using TNRE to recognize cross-source remote sensing data 