function [g1,g2,S1,S2,Z1,Z2,fval_seq]=TNRE(X1,X2,y1,y2,S1_init,d,lN,delta1,delta2,delta_tr)
%input:X1 samples from source 1
%input:X2 samples from source 2
%input:y1 labels for samples from source 1
%input:y2 labels for samples from source 2
%input:y2 labels for samples from source 2
%input:rank_N the rank of tensor ring
%input:delta1,delta2,delta_tr denote the regularization parameters.
%output:g1 factor tensors of TNR for source 1
%output:g2 factor tensors of TNR for source 2
%output:S1 latent domain labels for samples from source 1
%output:S2 latent domain labels for samples from source 2
%output:Z1 adaptatived features of source 1
%output:Z2 adaptatived features of source 2
%output:fval_seq function value for each iteration
%edited by Tong Gao in 7/7 2024
N1=size(X1,2);
L1=ndims(X1{1});
N2=size(X2,2);
L2=ndims(X1{2});
mL=sum(lN);
y=[y1;y2];
feaDim1=d(1);
feaDim2=d(2);
%initialize the factor tensors
s=size(X1{1});
Xs=tenzeros([s,N1]);
for i=1:N1
    Xs(:,:,:,:,i)=X1{i};
end
% g1=TR_decomposition(Xs,[rank_N_1,rank_N_1(end)]);
g1=TNR_decomposition_(Xs,d(1),d(2),delta_tr);
g1{end}=[];
s=size(X2{1});
Xt=tenzeros([s,N2]);
for i=1:N2
    Xt(:,:,:,:,i)=X2{i};
end
g2=TNR_decomposition_(Xt,d(1),d(2),delta_tr);
g2{end}=[];

M=zeros(mL,mL);
y_l=zeros(1,sum(lN));
for i=1:max(y)
y_l(sum(lN(1:i-1))+1:sum(lN(1:i)))=i;
end
for i=1:mL
    a=zeros(mL,1);
    a(y_l~=y_l(i))=-1/size(find(y_l~=y_l(i)),2);
    a(i)=1;
    M=M+a*a';
end
% initialize Z
Z1=zeros(feaDim1*feaDim2,N1);
Z2=zeros(feaDim1*feaDim2,N2);
G=ttt(g1{1},g1{2},3,1);
for i=3:L1
    temp=ndims(G);
    G=ttt(G,g1{i},temp,1);
end
tempDim=ndims(G);
for i=1:N1
    temp=ttt(X1{i},G,[1:L1],[2:tempDim-1]);
    Z1(:,i)=temp.data(:);
end
G=ttt(g2{1},g2{2},3,1);
for i=3:L2
    temp=ndims(G);
    G=ttt(G,g2{i},temp,1);
end
tempDim=ndims(G);
for i=1:N2
    temp=ttt(X2{i},G,[1:L2],[2:tempDim-1]);
    Z2(:,i)=temp.data(:);
end
yw1=ones(N1,1);
yw2=ones(N2,1);
yw1(y1==0)=0.1;
yw2(y2==0)=0.3;
S1=zeros(mL,N1);
S1(S1_init>0)=1;
S2=zeros(mL,N2);
for i=1:N2
    if y2(i)==0
    S2(:,i)=rand(mL,1);
    S2(:,i)=S2(:,i)/sum(S2(:,i));
    else
        temp=ceil(rand(1)*lN(y2(i)));
        S2(sum(lN(1:y2(i)-1))+temp,i)=1;
    end
end
%initialize latent domain centroid C
C1=Z1*S1_init';
S2_init=(diag(1./(sum(S2,2)+0.0001)))*S2;
C2=Z2*S2_init';
C=(C1+C2)/2;
% delta2=0;
iterNum=1;
fval=0;
while true
fval_l=fval;
nOrder1=mod(iterNum,L1-1)+2;
nOrder2=mod(iterNum,L2-1)+2;
%update Z1 and Z2
Z1=C*S1;
Z2=C*S2;
%update g factor tensors with 2-L order
rS=[nOrder1+1:L1+1,1:nOrder1-1];
ZG=zeros(size(g1{nOrder1},1)*size(g1{nOrder1},3),size(g1{nOrder1},1)*size(g1{nOrder1},3));
ZGX=zeros(size(g1{nOrder1},1)*size(g1{nOrder1},2)*size(g1{nOrder1},3),1);
for j=1:N1
    if rS(1)~=L1+1
        G1=g1{rS(1)};
    else
        temp2=zeros(feaDim1,feaDim2);
        temp2(:)=Z1(:,j);
        temp2=tensor(temp2');
        G1=temp2;
    end
for i=rS(2:end)
    if i~=L1+1
        temp=ndims(G1);
        G1=ttt(G1,g1{i},temp,1);
    else
        temp=ndims(G1);
        temp2=zeros(feaDim1,feaDim2);
        temp2(:)=Z1(:,j);
        temp2=temp2';
        G1=ttt(G1,tensor(temp2),temp,1);
    end
end
temp=ndims(G1);
temp2=ttt(G1,G1,[2:temp-1],[2:temp-1]);
temp3=permute(temp2,[2,1,4,3]);
temp_ZG=zeros(size(g1{nOrder1},1)*size(g1{nOrder1},3),size(g1{nOrder1},1)*size(g1{nOrder1},3));
temp_ZG(:)=temp3.data(:);
ZG=ZG+yw1(j)*temp_ZG;
temp=ndims(G1);
temp2=ttt(X1{j},G1,[nOrder1+1:L1,1:nOrder1-1],[2:temp-1]);
temp3=permute(temp2,[3,2,1]);
ZGX=ZGX-2*yw1(j)*temp3.data(:);
end
ZG_H=kron(eye(size(g1{nOrder1},2)),ZG);
temp=g1{nOrder1};
X0=double(tenmat(temp,[1,2],3));
[X_r,fval]=orth_Constrain_solving2(ZG_H,ZGX(:),X0,size(g1{nOrder1},1),size(g1{nOrder1},2),size(g1{nOrder1},3));
g1{nOrder1}=tensor(X_r(:),[size(g1{nOrder1},1),size(g1{nOrder1},2),size(g1{nOrder1},3)]);

rS=[nOrder2+1:L2+1,1:nOrder2-1];
ZG=zeros(size(g2{nOrder2},1)*size(g2{nOrder2},3),size(g2{nOrder2},1)*size(g2{nOrder2},3));
ZGX=zeros(size(g2{nOrder2},1)*size(g2{nOrder2},2)*size(g2{nOrder2},3),1);
for j=1:N2
    if rS(1)~=L2+1
        G1=g2{rS(1)};
    else
        temp2=zeros(feaDim1,feaDim2);
        temp2(:)=Z2(:,j);
        temp2=tensor(temp2');
        G1=temp2;
    end
for i=rS(2:end)
    if i~=L2+1
        temp=ndims(G1);
        G1=ttt(G1,g2{i},temp,1);
    else
        temp=ndims(G1);
        temp2=zeros(feaDim1,feaDim2);
        temp2(:)=Z2(:,j);
        temp2=temp2';
        G1=ttt(G1,tensor(temp2),temp,1);
    end
end
temp=ndims(G1);
temp2=ttt(G1,G1,[2:temp-1],[2:temp-1]);
temp3=permute(temp2,[2,1,4,3]);
temp_ZG=zeros(size(g2{nOrder2},1)*size(g2{nOrder2},3),size(g2{nOrder2},1)*size(g2{nOrder2},3));
temp_ZG(:)=temp3.data(:);
ZG=ZG+yw2(j)*temp_ZG;
temp=ndims(G1);
temp2=ttt(X2{j},G1,[nOrder2+1:L1,1:nOrder2-1],[2:temp-1]);
temp3=permute(temp2,[3,2,1]);
ZGX=ZGX-2*yw2(j)*temp3.data(:);
end
ZG_H=kron(eye(size(g2{nOrder2},2)),ZG);
temp=g2{nOrder2};
X0=double(tenmat(temp,[1,2],3));
[X_r,fval]=orth_Constrain_solving2(ZG_H,ZGX(:),X0,size(g2{nOrder2},1),size(g2{nOrder2},2),size(g2{nOrder2},3));
g2{nOrder2}=tensor(X_r(:),[size(g2{nOrder2},1),size(g2{nOrder2},2),size(g2{nOrder2},3)]);



%update g factor tensors with 1 order
rS=[2:L1+1];
ZGX=zeros(size(g1{1},1)*size(g1{1},3),size(g1{1},2));
for j=1:N1
    G1=g1{rS(1)};
for i=rS(2:end)
    if i~=L1+1
        temp=ndims(G1);
        G1=ttt(G1,g1{i},temp,1);
    else
        temp=ndims(G1);
        temp2=zeros(feaDim1,feaDim2);
        temp2(:)=Z1(:,j);
        temp2=temp2';
        G1=ttt(G1,tensor(temp2),temp,1);
    end
end
temp=ndims(G1);
temp2=ttt(X1{j},G1,[2:L1],[2:temp-1]);
temp3=tenmat(temp2,[3,2],1);
ZGX=ZGX+yw1(j)*temp3.data;
end
% [U,~,V]=svds(ZGX,size(g1{1},1)*size(g1{1},3));
[U,~,V]=svd(ZGX);
temp_g1=V(:,1:size(g1{1},1)*size(g1{1},3))*U';
temp_g1_t=tensor(temp_g1(:),[size(g1{1},2),size(g1{1},1),size(g1{1},3)]);
g1{1}=permute(temp_g1_t,[2,1,3]);

rS=[2:L2+1];
ZGX=zeros(size(g2{1},1)*size(g2{1},3),size(g2{1},2));
for j=1:N2
    G1=g2{rS(1)};
for i=rS(2:end)
    if i~=L2+1
        temp=ndims(G1);
        G1=ttt(G1,g2{i},temp,1);
    else
        temp=ndims(G1);
        temp2=zeros(feaDim1,feaDim2);
        temp2(:)=Z2(:,j);
        temp2=temp2';
        G1=ttt(G1,tensor(temp2),temp,1);
    end
end
temp=ndims(G1);
temp2=ttt(X2{j},G1,[2:L2],[2:temp-1]);
temp3=tenmat(temp2,[3,2],1);
ZGX=ZGX+yw2(j)*temp3.data;
end
% [U,~,V]=svds(ZGX,size(g2{1},1)*size(g2{1},3));
[U,~,V]=svd(ZGX);
temp_g1=V(:,1:size(g2{1},1)*size(g2{1},3))*U';
temp_g1_t=tensor(temp_g1(:),[size(g2{1},2),size(g2{1},1),size(g2{1},3)]);
g2{1}=permute(temp_g1_t,[2,1,3]);

%update Z_1 and Z_2
Z_1=zeros(feaDim1*feaDim2,N1);
Z1_D=zeros(feaDim1*feaDim2,N1);
G=ttt(g1{1},g1{2},3,1);
for i=3:L1
    temp=ndims(G);
    G=ttt(G,g1{i},temp,1);
end
tempDim=ndims(G);
for i=1:N1
    temp=ttt(X1{i},G,[1:L2],[2:tempDim-1]);
    Z1_D(:,i)=temp.data(:);
end
Z_1(:)=Z1_D(:);

Z_2=zeros(feaDim1*feaDim2,N2);
Z2_D=zeros(feaDim1*feaDim2,N2);
G=ttt(g2{1},g2{2},3,1);
for i=3:L2
    temp=ndims(G);
    G=ttt(G,g2{i},temp,1);
end
tempDim=ndims(G);
for i=1:N2
    temp=ttt(X2{i},G,[1:L2],[2:tempDim-1]);
    Z2_D(:,i)=temp.data(:);
end
Z_2(:)=Z2_D(:);

%update S

D=pdist2([Z_2'],C');
S2=zeros(mL,N2);
for i=1:N2
    if y2(i)~=0
        temp=D(i,:);
        temp(sum(lN(1:y2(i)-1))+1:sum(lN(1:y2(i))))=temp(sum(lN(1:y2(i)-1))+1:sum(lN(1:y2(i))))*0.00001;
        [~,ind]=min(temp);
        S2(ind,i)=1;
    else
        temp=D(i,:);
        [~,ind]=min(temp);
        S2(ind,i)=1;
    end
end

%%
%update latent domain centroid C
for i=1:mL
temp1=S1*diag(yw1)*S1';
temp2=S2*diag(yw2)*S2';
C_2_d=delta1*temp1(i,i)'+delta1*temp2(i,i)'-delta2*M(i,i);
C_temp=C;
C_temp(:,i)=0;
C_1_d=delta1*S1(i,:)*diag(yw1)*Z_1'+delta1*S2(i,:)*diag(yw2)*Z_2'-delta1*temp1(i,:)*C_temp'-delta1*temp2(i,:)*C_temp'+delta2*M(i,:)*C_temp';
C_v=C_1_d/C_2_d;
C(:,i)=C_v;
end

iterNum=iterNum+1;
fval1=0;
G1=g1{1};
for i=2:L1
    temp=ndims(G1);
    G1=ttt(G1,g1{i},temp,1);
end
% temp=ndims(G1);
% ttt(G1,G1,[2:temp-1],[2:temp-1])
for i=1:N1
    temp=ndims(G1);
    temp2=zeros(feaDim1,feaDim2);
    temp2(:)=Z1(:,i);
    Z_temp=tensor(temp2);
    G1_Z=ttt(G1,Z_temp,[1,temp],[1,2]);
    fval1=fval1+yw1(i)*norm(X1{i}.data(:)-G1_Z.data(:))^2;
end
G1=g2{1};
for i=2:L2
    temp=ndims(G1);
    G1=ttt(G1,g2{i},temp,1);
end
for i=1:N2
    temp=ndims(G1);
    temp2=zeros(feaDim1,feaDim2);
    temp2(:)=Z2(:,i);
    Z_temp=tensor(temp2);
    G1_Z=ttt(G1,Z_temp,[1,temp],[1,2]);
    fval1=fval1+yw2(i)*norm(X2{i}.data(:)-G1_Z.data(:))^2;
end
fval3=trace(C*M*C');
fval=fval1-delta2*fval3
fval_seq(iterNum)=fval;
if iterNum>10||abs(fval-fval_l)<0.01
break;
end

end
% TR.Storage=0;
% TR.Storage  = Dim_TT(g1) + Dim_TT(g2)+size(g1{1},1)*size(g1{end},3) * (size(X1, 2)+size(X2, 2));
end