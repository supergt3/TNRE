addpath(genpath(['.\tensor_toolbox']));
addpath(genpath(['.\libsvm-3.25']));
load samples.mat

Label1=y1; %labels
Label2=y2; %labels
M=3;% the number of classes
temp=cumprod(size(X1{1}));
X1_vec=zeros(temp(end),size(y1(:),1));
for i=1:size(y1(:),1)
X1_vec(:,i)=X1{i}.data(:);
end
lN=1*ones(1,M);
S1_init=zeros(sum(lN),size(y1(:),1));
for i=1:M
[Ind,centroid]=kmeans(X1_vec(:,y1==i),lN(i));
tInd=find(y1==i);
for h=1:size(Ind(:),1)
S1_init(sum(lN(1:i-1))+Ind(h),tInd(h))=1;
end
end
S1_init=diag(1./sum(S1_init,2))*S1_init;
y2(1:1.2:end)=0;% unlabeled samples

rank_N_1=[14,14,14,14];
rank_N_2=[14,14,14];
d=[3,5];
feaDim1=d(1);
feaDim2=d(2);

[g1,g2,S1,S2,Z1,Z2,fval_seq]=TNRE(X1,X2,y1,y2,S1_init,d,lN,1,0.1,0.3);% using TNRE method

%compute the transferred results
N1=size(y1(:),1);
N2=size(y2(:),1);
L1=ndims(X1{1});
L2=ndims(X1{2});
Z1=zeros(feaDim1*feaDim2,N1);
Z2=zeros(feaDim1*feaDim2,N2);
G=ttt(g1{1},g1{2},3,1);
for i=3:L1
    temp=ndims(G);
    G=ttt(G,g1{i},temp,1);
end
tempDim=ndims(G);
for i=1:N1
    temp=ttt(X1{i},G,[1:L1],[2:tempDim-1]);
    Z1(:,i)=temp.data(:);
end
G=ttt(g2{1},g2{2},3,1);
for i=3:L2
    temp=ndims(G);
    G=ttt(G,g2{i},temp,1);
end
tempDim=ndims(G);
for i=1:N2
    temp=ttt(X2{i},G,[1:L2],[2:tempDim-1]);
    Z2(:,i)=temp.data(:);
end

%1NN
% ind_W=diag(Ws);
Mdl = fitcknn([Z2]',[Label2],'NumNeighbors',1);
Label_p = predict(Mdl,Z1');
acc_1NN=size(find(Label_p==Label1),1)/size(y1,1);% cross-source recognition accuracy using 1NN
%SVM
model = svmtrain(Label2, Z2', '-s 0 -t 0 -c 1');%SVM璁粌
[predict_label,acc_temp,prob] = svmpredict(Label1,Z1', model,'-b 0');
acc_SVM=size(find(predict_label==Label1),1)/size(y1,1);% cross-source recognition accuracy using SVM


