function t = uplus(t)
%UPLUS Unary plus for a symktensor. 
%
%   See also SYMKTENSOR.
%
%Tensor Toolbox for MATLAB: <a href="https://www.tensortoolbox.org">www.tensortoolbox.org</a>



% This function does nothing!

