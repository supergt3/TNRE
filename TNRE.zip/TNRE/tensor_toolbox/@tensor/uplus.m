function t = uplus(t)
%UPLUS Unary plus (+) for tensors.
%
%   See also TENSOR.
%
%Tensor Toolbox for MATLAB: <a href="https://www.tensortoolbox.org">www.tensortoolbox.org</a>



% This function does nothing!

